import '../../css/App.css'
import './footer.css'

const Footer = () => {
    return (
        <section class="footer-site">
            <div class="container">
                <p class="text-center lead">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat, illum.
                </p>
            </div>
        </section>
    )
}

export default Footer;