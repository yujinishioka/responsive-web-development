import { HeaderStyle } from '../style/header';

const Header = () => {
    return (
        <HeaderStyle className="container">
            <h1>Global Car</h1>
        </HeaderStyle>
    )
}

export default Header;