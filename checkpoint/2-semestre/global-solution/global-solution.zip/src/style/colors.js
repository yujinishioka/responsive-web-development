export default {
    primaryColor: '#EBB92D',
    greyBackground: '#60605D',
    darkGreyBackground: '#52524F',
}